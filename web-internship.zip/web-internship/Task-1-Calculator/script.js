// ===== Calculator logic (no eval, no Function) =====

// State
let tokens = [];          // finished part of the expression, e.g. [2, "+", 3, "*"]
let currentInput = "0";   // the number being typed (string). "" means an operator was just pressed
let justEvaluated = false; // true right after "=" is pressed
let hasError = false;

const expressionEl = document.getElementById("expression");
const currentEl = document.getElementById("current");
const MAX_DIGITS = 15;

// Symbols for showing operators nicely on the screen
const symbols = { "+": "+", "-": "−", "*": "×", "/": "÷" };

// ---------- Display ----------
function updateDisplay() {
  const text = tokens.map(t => (typeof t === "number" ? t : symbols[t])).join(" ");
  expressionEl.textContent = text;

  // If an operator is pending, keep showing the last number
  let shown = currentInput;
  if (currentInput === "" && tokens.length >= 2) shown = String(tokens[tokens.length - 2]);

  currentEl.textContent = shown;
  currentEl.classList.toggle("error", hasError);
  currentEl.classList.toggle("small", !hasError && shown.length > 11);
}

function resetAll() {
  tokens = [];
  currentInput = "0";
  justEvaluated = false;
  hasError = false;
}

// If the last action was "=" or an error, a new number starts a fresh calculation
function startFreshIfNeeded() {
  if (hasError || justEvaluated) resetAll();
}

// ---------- Input handlers ----------
function inputDigit(digit) {
  startFreshIfNeeded();
  if (currentInput.replace(/[-.]/g, "").length >= MAX_DIGITS) return;
  if (currentInput === "0" || currentInput === "") currentInput = digit;
  else currentInput += digit;
  updateDisplay();
}

function inputDecimal() {
  startFreshIfNeeded();
  if (currentInput === "") currentInput = "0.";       // after an operator: start "0."
  else if (!currentInput.includes(".")) currentInput += "."; // only one dot per number
  updateDisplay();
}

function inputOperator(operator) {
  if (hasError) return;
  justEvaluated = false;

  if (currentInput === "") {
    // Prevent two operators in a row: replace the previous one
    tokens[tokens.length - 1] = operator;
  } else {
    tokens.push(Number(currentInput), operator); // operator chaining: 2 + 3 * ...
    currentInput = "";
  }
  updateDisplay();
}

function backspace() {
  if (hasError || justEvaluated) { resetAll(); updateDisplay(); return; }

  if (currentInput === "") {
    // Undo the pending operator and bring the previous number back for editing
    tokens.pop();
    currentInput = String(tokens.pop());
  } else {
    currentInput = currentInput.slice(0, -1);
    if (currentInput === "" || currentInput === "-") currentInput = "0";
  }
  updateDisplay();
}

// ---------- Calculation ----------
// Two passes give correct precedence: first * and /, then + and -
function evaluate(list) {
  const afterMultiplyDivide = [list[0]];
  for (let i = 1; i < list.length; i += 2) {
    const operator = list[i];
    const nextNumber = list[i + 1];
    if (operator === "*" || operator === "/") {
      const previous = afterMultiplyDivide.pop();
      if (operator === "/" && nextNumber === 0) return null; // division by zero
      afterMultiplyDivide.push(operator === "*" ? previous * nextNumber : previous / nextNumber);
    } else {
      afterMultiplyDivide.push(operator, nextNumber);
    }
  }

  let result = afterMultiplyDivide[0];
  for (let i = 1; i < afterMultiplyDivide.length; i += 2) {
    const nextNumber = afterMultiplyDivide[i + 1];
    result = afterMultiplyDivide[i] === "+" ? result + nextNumber : result - nextNumber;
  }
  return result;
}

function calculate() {
  if (hasError || tokens.length === 0) return;

  // If the expression ends with an operator (like "5 +"), ignore that operator
  if (currentInput === "") { tokens.pop(); currentInput = String(tokens.pop()); }

  const fullExpression = [...tokens, Number(currentInput)];
  const shownExpression = fullExpression.map(t => (typeof t === "number" ? t : symbols[t])).join(" ");
  const result = evaluate(fullExpression);

  if (result === null) {
    hasError = true;
    tokens = [];
    currentInput = "Cannot divide by 0";
    updateDisplay();
    return;
  }

  // toPrecision fixes 0.1 + 0.2 = 0.30000000000000004 style errors
  const cleanResult = parseFloat(result.toPrecision(12));
  tokens = [];
  currentInput = String(cleanResult);
  justEvaluated = true;
  updateDisplay();
  expressionEl.textContent = shownExpression + " =";
}

// ---------- Connect buttons (addEventListener, no inline onclick) ----------
document.querySelectorAll("[data-digit]").forEach(btn =>
  btn.addEventListener("click", () => inputDigit(btn.dataset.digit)));
document.querySelectorAll("[data-operator]").forEach(btn =>
  btn.addEventListener("click", () => inputOperator(btn.dataset.operator)));

document.querySelector('[data-action="decimal"]').addEventListener("click", inputDecimal);
document.querySelector('[data-action="equals"]').addEventListener("click", calculate);
document.querySelector('[data-action="backspace"]').addEventListener("click", backspace);
document.querySelector('[data-action="clear"]').addEventListener("click", () => { resetAll(); updateDisplay(); });

// Bonus: keyboard support
document.addEventListener("keydown", (event) => {
  if (event.key >= "0" && event.key <= "9") inputDigit(event.key);
  else if (event.key === ".") inputDecimal();
  else if ("+-*/".includes(event.key)) inputOperator(event.key);
  else if (event.key === "Enter" || event.key === "=") { event.preventDefault(); calculate(); }
  else if (event.key === "Backspace") backspace();
  else if (event.key === "Escape") { resetAll(); updateDisplay(); }
});

updateDisplay();
