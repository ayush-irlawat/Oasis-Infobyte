// ===== Frontend script shared by all pages =====
// Each page only has some elements, so we check whether they exist first.

const messageEl = document.getElementById("message");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const logoutBtn = document.getElementById("logoutBtn");
const welcomeEl = document.getElementById("welcome");

function showMessage(text, type) {
  messageEl.textContent = text;
  messageEl.className = "message " + type;   // "error" or "success"
}

// Sends JSON to the server and returns { ok, data }
async function postJson(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {})
  });
  const data = await response.json();
  return { ok: response.ok, data: data };
}

// Handles both forms. Frontend checks only improve user experience; the server validates again.
function handleForm(form, url, onSuccess, checkPassword) {
  form.addEventListener("submit", async (event) => {
    event.preventDefault();                  // stop the page from reloading
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    const button = form.querySelector("button");

    if (!username || !password) return showMessage("Please fill in both fields.", "error");
    if (checkPassword && password.length < 8) return showMessage("Password must be at least 8 characters.", "error");
    if (checkPassword && !/\d/.test(password)) return showMessage("Password must contain at least one number.", "error");

    button.disabled = true;
    try {
      const result = await postJson(url, { username, password });
      showMessage(result.data.message, result.ok ? "success" : "error");
      if (result.ok) onSuccess();
    } catch (error) {
      showMessage("Cannot reach the server. Is it running?", "error");
    }
    button.disabled = false;
  });
}

// ----- Login page -----
if (loginForm) {
  handleForm(loginForm, "/api/login", () => { window.location.href = "/dashboard"; }, false);
}

// ----- Register page -----
if (registerForm) {
  handleForm(registerForm, "/api/register", () => {
    setTimeout(() => { window.location.href = "index.html"; }, 1500);
  }, true);
}

// ----- Dashboard page -----
if (welcomeEl) {
  fetch("/api/me")
    .then(res => {
      if (!res.ok) throw new Error("not logged in");
      return res.json();
    })
    .then(data => { welcomeEl.textContent = "Welcome, " + data.username + "!"; })
    .catch(() => { window.location.href = "index.html"; });
}

if (logoutBtn) {
  logoutBtn.addEventListener("click", async () => {
    await postJson("/api/logout");
    window.location.href = "index.html";
  });
}
