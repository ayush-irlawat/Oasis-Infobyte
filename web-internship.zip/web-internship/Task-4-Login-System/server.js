// ===== Login Authentication System (learning project) =====
require("dotenv").config();               // loads values from the .env file
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

// The session secret must come from the environment, never from the source code
if (!process.env.SESSION_SECRET) {
  console.error("Missing SESSION_SECRET. Copy .env.example to .env and set a value.");
  process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 3000;
const USERS_FILE = path.join(__dirname, "users.json");

// ---------- Middleware ----------
app.use(express.json());                  // lets us read JSON sent by the browser
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,               // no session until the user logs in
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 1000 * 60 * 60 } // 1 hour
}));

// ---------- Helpers for the JSON file ----------
function readUsers() {
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
  } catch (error) {
    return [];
  }
}
function writeUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

// Blocks access to protected pages/routes when the user is not logged in
function requireLogin(req, res, next) {
  if (req.session.username) return next();
  if (req.originalUrl.startsWith("/api/")) return res.status(401).json({ message: "Not logged in." });
  res.redirect("/");                      // login page
}

// ---------- Protected dashboard ----------
// Declared BEFORE express.static so the file can't be opened directly from /public
app.get("/dashboard.html", (req, res) => res.redirect("/dashboard"));
app.get("/dashboard", requireLogin, (req, res) => {
  res.set("Cache-Control", "no-store");   // stops the back button showing it after logout
  res.sendFile(path.join(__dirname, "public", "dashboard.html"));
});

app.use(express.static(path.join(__dirname, "public")));

// ---------- API routes ----------
app.post("/api/register", async (req, res) => {
  // Server-side validation (never trust the frontend alone)
  const username = typeof req.body.username === "string" ? req.body.username.trim() : "";
  const password = typeof req.body.password === "string" ? req.body.password : "";

  if (!username || !password) {
    return res.status(400).json({ message: "Username/email and password are required." });
  }
  if (username.length < 3 || username.length > 50) {
    return res.status(400).json({ message: "Username/email must be 3 to 50 characters." });
  }
  if (password.length < 8) {
    return res.status(400).json({ message: "Password must be at least 8 characters." });
  }
  if (!/\d/.test(password)) {
    return res.status(400).json({ message: "Password must contain at least one number." });
  }

  const users = readUsers();
  const alreadyExists = users.some(u => u.username.toLowerCase() === username.toLowerCase());
  if (alreadyExists) {
    return res.status(409).json({ message: "That username/email is already registered." });
  }

  const passwordHash = await bcrypt.hash(password, 10); // 10 = salt rounds
  users.push({ username, passwordHash, createdAt: new Date().toISOString() });
  writeUsers(users);
  res.status(201).json({ message: "Registration successful! Redirecting to login..." });
});

app.post("/api/login", async (req, res) => {
  const username = typeof req.body.username === "string" ? req.body.username.trim() : "";
  const password = typeof req.body.password === "string" ? req.body.password : "";

  if (!username || !password) {
    return res.status(400).json({ message: "Please enter both username/email and password." });
  }

  const user = readUsers().find(u => u.username.toLowerCase() === username.toLowerCase());
  const passwordMatches = user ? await bcrypt.compare(password, user.passwordHash) : false;

  if (!passwordMatches) {
    // Same message for "no such user" and "wrong password" so attackers learn nothing
    return res.status(401).json({ message: "Invalid username/email or password." });
  }

  // regenerate() gives a fresh session id after login (protects against session fixation)
  req.session.regenerate((error) => {
    if (error) return res.status(500).json({ message: "Something went wrong. Try again." });
    req.session.username = user.username;
    res.json({ message: "Login successful." });
  });
});

app.get("/api/me", requireLogin, (req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({ username: req.session.username });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => {             // removes the session on the server
    res.clearCookie("connect.sid");
    res.json({ message: "Logged out." });
  });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
