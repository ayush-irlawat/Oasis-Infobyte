// ===== To-Do App =====
const STORAGE_KEY = "todoTasks";

// Each task: { id, text, completed, createdAt, completedAt }
let tasks = loadTasks();
let editingId = null; // id of the task currently being edited (null = none)

const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const messageEl = document.getElementById("message");
const pendingList = document.getElementById("pendingList");
const completedList = document.getElementById("completedList");
const pendingCount = document.getElementById("pendingCount");
const completedCount = document.getElementById("completedCount");
const pendingEmpty = document.getElementById("pendingEmpty");
const completedEmpty = document.getElementById("completedEmpty");

// ---------- localStorage ----------
function loadTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch (error) {
    return []; // corrupted data or storage blocked
  }
}

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (error) {
    showMessage("Could not save tasks in this browser.");
  }
}

// ---------- Helpers ----------
function formatTime(isoString) {
  return new Date(isoString).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

function showMessage(text) {
  messageEl.textContent = text;
}

// ---------- Task actions ----------
function addTask() {
  const text = taskInput.value.trim();
  if (text === "") {
    showMessage("Please type a task first.");
    return;
  }
  showMessage("");
  tasks.push({
    id: Date.now(),                       // unique enough for a small app
    text: text,
    completed: false,
    createdAt: new Date().toISOString(),
    completedAt: null
  });
  taskInput.value = "";
  taskInput.focus();
  saveTasks();
  render();
}

function completeTask(id) {
  const task = tasks.find(t => t.id === id);
  task.completed = true;
  task.completedAt = new Date().toISOString();
  saveTasks();
  render();
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  if (editingId === id) editingId = null;
  saveTasks();
  render();
}

function saveEdit(id, newText) {
  const text = newText.trim();
  if (text === "") {
    showMessage("A task cannot be empty. Edit it or delete it.");
    return;
  }
  showMessage("");
  tasks.find(t => t.id === id).text = text;
  editingId = null;
  saveTasks();
  render();
}

// ---------- Rendering ----------
function makeButton(label, className, onClick) {
  const btn = document.createElement("button");
  btn.textContent = label;
  btn.className = "btn " + className;
  btn.addEventListener("click", onClick);
  return btn;
}

function createTaskElement(task) {
  const li = document.createElement("li");
  li.className = "task" + (task.completed ? " completed" : "");

  const main = document.createElement("div");
  main.className = "task-main";
  const actions = document.createElement("div");
  actions.className = "actions";

  if (editingId === task.id) {
    // Edit mode: show an input with Save / Cancel
    const input = document.createElement("input");
    input.type = "text";
    input.className = "edit-input";
    input.value = task.text;
    input.maxLength = 120;
    input.addEventListener("keydown", e => {
      if (e.key === "Enter") saveEdit(task.id, input.value);
      if (e.key === "Escape") { editingId = null; render(); }
    });
    main.appendChild(input);
    actions.appendChild(makeButton("Save", "save", () => saveEdit(task.id, input.value)));
    actions.appendChild(makeButton("Cancel", "cancel", () => { editingId = null; showMessage(""); render(); }));
    setTimeout(() => input.focus(), 0);
  } else {
    const text = document.createElement("span");
    text.className = "task-text";
    text.textContent = task.text;           // textContent keeps user input safe from HTML injection
    main.appendChild(text);

    if (!task.completed) actions.appendChild(makeButton("Complete", "complete", () => completeTask(task.id)));
    actions.appendChild(makeButton("Edit", "edit", () => { editingId = task.id; render(); }));
    actions.appendChild(makeButton("Delete", "delete", () => deleteTask(task.id)));
  }
  main.appendChild(actions);
  li.appendChild(main);

  const time = document.createElement("div");
  time.className = "time";
  time.textContent = "Added: " + formatTime(task.createdAt) +
    (task.completed ? "  |  Completed: " + formatTime(task.completedAt) : "");
  li.appendChild(time);
  return li;
}

function render() {
  pendingList.innerHTML = "";
  completedList.innerHTML = "";

  const pending = tasks.filter(t => !t.completed);
  const completed = tasks.filter(t => t.completed);

  pending.forEach(t => pendingList.appendChild(createTaskElement(t)));
  completed.forEach(t => completedList.appendChild(createTaskElement(t)));

  pendingCount.textContent = pending.length;
  completedCount.textContent = completed.length;
  pendingEmpty.classList.toggle("hidden", pending.length > 0);
  completedEmpty.classList.toggle("hidden", completed.length > 0);
}

// ---------- Events ----------
addBtn.addEventListener("click", addTask);
taskInput.addEventListener("keydown", e => { if (e.key === "Enter") addTask(); });

render(); // restores saved tasks on page load
