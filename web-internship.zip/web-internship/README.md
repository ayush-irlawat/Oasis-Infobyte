# Web Development Internship – 4 Tasks

| Folder | What it is | How to run |
|---|---|---|
| Task-1-Calculator | HTML/CSS/JS calculator (no eval, operator precedence) | Open `index.html` (VS Code: Live Server) |
| Task-2-Tribute-Page | Tribute to Ayrton Senna (HTML/CSS) | Add `senna.jpg` (see its README.txt), then open `index.html` |
| Task-3-Todo-App | To-Do app with localStorage | Open `index.html` |
| Task-4-Login-System | Node + Express + bcryptjs + express-session | See below |

## Task 4 – run on Windows 11 + VS Code
1. Install Node.js LTS from https://nodejs.org, then check: `node -v` and `npm -v`.
2. Open the `Task-4-Login-System` folder in VS Code, open the Terminal.
3. `npm install`
4. Copy `.env.example` to `.env` (`copy .env.example .env`) and set a long random `SESSION_SECRET`.
5. `npm start`, then open http://localhost:3000

## Limitations (learning project, not production)
- `users.json` is a flat file: no locking (simultaneous writes can clash), no scaling, no backups, and anyone with file access can read the hashes.
- Default session store is in memory: all sessions vanish on restart, memory grows with users, and it cannot be shared across servers. Production would use a database and a session store such as Redis.
- Missing for production: HTTPS and `secure` cookies, rate limiting / lockout against brute force, CSRF protection, email verification, password reset.

## Common errors
- `Missing SESSION_SECRET` -> create `.env` from `.env.example`.
- `Cannot find module 'express'` -> run `npm install` inside Task-4-Login-System.
- `EADDRINUSE` (port busy) -> change `PORT` in `.env`.
- Tribute image not showing -> add `senna.jpg` next to `index.html`.
- Login page opens by double-click and does nothing -> use `http://localhost:3000`, not the file path.
