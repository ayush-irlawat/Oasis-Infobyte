IMAGE:
The page loads the photo directly from Wikimedia Commons (internet required):
https://commons.wikimedia.org/wiki/File:Ayrton_Senna_1988_Canada.jpg

OFFLINE / LOCAL COPY (optional):
1. Download the image from the page above, save it here as senna.jpg.
2. In index.html change the img src to "senna.jpg".

Check the licence on the Commons page before submitting. The caption already credits the author.
